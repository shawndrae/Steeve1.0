import React from 'react';

function App() {
  return (
    <div style={{ padding: 50, fontFamily: 'Arial' }}>
      <h1>Welcome to Steeve 1.0</h1>
      <p>Your calling app is coming soon!</p>
    </div>
  );
}

export default App;
