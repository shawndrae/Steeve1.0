const plivoService = require('../services/plivoService');

exports.startCall = async (req, res) => {
  const { toNumber, fromUserId } = req.body;

  try {
    const response = await plivoService.makeCall(toNumber);
    res.status(200).json({ success: true, data: response });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getUsage = (req, res) => {
  const { userId } = req.params;
  // Placeholder: return mocked usage data
  res.json({ used: 120, limit: 1000 });
};