const express = require('express');
const router = express.Router();
const { startCall, getUsage } = require('../controllers/callController');

router.post('/start', startCall);
router.get('/usage/:userId', getUsage);

module.exports = router;