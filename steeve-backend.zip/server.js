const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const callRoutes = require('./routes/callRoutes');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/call', callRoutes);

app.get('/', (req, res) => {
  res.send('Steeve backend running');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is live at http://localhost:${PORT}`);
});