const plivo = require('plivo');
const client = new plivo.Client(process.env.PLIVO_AUTH_ID, process.env.PLIVO_AUTH_TOKEN);

exports.makeCall = async (toNumber) => {
  return await client.calls.create(
    process.env.PLIVO_PHONE_NUMBER,
    toNumber,
    'http://your-server.com/answer_url'
  );
};